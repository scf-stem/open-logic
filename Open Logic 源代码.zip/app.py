import os
from flask import Flask, render_template
from dotenv import load_dotenv

load_dotenv() # Load .env file

from config import DevelopmentConfig, ProductionConfig
from extensions import db, migrate, cors
from routes import auth_bp, posts_bp, comments_bp, runner_bp, courses_bp

def create_app(config_class=DevelopmentConfig):
    app = Flask(__name__)
    app.config.from_object(config_class)

    # Initialize Extensions
    db.init_app(app)
    migrate.init_app(app, db)
    cors.init_app(app)

    # Register Blueprints
    app.register_blueprint(auth_bp)
    app.register_blueprint(posts_bp)
    app.register_blueprint(comments_bp)
    app.register_blueprint(runner_bp)
    app.register_blueprint(courses_bp)

    # Frontend Routes (Serving Templates)
    @app.route('/')
    def index():
        return render_template('index.html')

    @app.route('/login')
    def login_page():
        return render_template('login.html')
        
    @app.route('/register')
    def register_page():
        return render_template('register.html')

    @app.route('/create')
    def create_post_page():
        return render_template('post_create.html')

    @app.route('/guidelines')
    def guidelines_page():
        return render_template('guidelines.html')

    @app.route('/about')
    def about_page():
        return render_template('about.html')

    @app.route('/profile')
    def profile_page():
        return render_template('profile.html')

    @app.route('/post/<int:post_id>')
    def post_detail(post_id):
        return render_template('post_detail.html')

    # Create Tables for MVP (Instead of migration for simplicity in prototype)
    with app.app_context():
        db.create_all()

    return app

# Determine configuration based on environment
config_name = os.environ.get('FLASK_CONFIG', 'development')
if config_name == 'production':
    app = create_app(ProductionConfig)
else:
    app = create_app(DevelopmentConfig)

if __name__ == '__main__':
    try:
        port = int(os.environ.get('PORT', 8080))
    except ValueError:
        port = 8080 # Fallback if PORT is not an integer (e.g. "${WEB_PORT}")
        
    print(f"Starting OSI Tutor Server at http://127.0.0.1:{port}")
    app.run(host='0.0.0.0', port=port)
