document.addEventListener('DOMContentLoaded', async () => {
    // 1. Check Login
    const userStr = localStorage.getItem('osi_user');
    if (!userStr) {
        window.location.href = '/login';
        return;
    }
    const user = JSON.parse(userStr);

    // 2. Render Profile Info
    document.getElementById('profileName').textContent = user.username;
    document.getElementById('profileAvatar').textContent = user.username[0].toUpperCase();
    if (user.created_at) {
        document.getElementById('profileDate').textContent = '加入于 ' + new Date(user.created_at).toLocaleDateString();
    }

    // 3. Load User Posts
    await loadUserPosts(user.id);
});

async function loadUserPosts(userId) {
    const container = document.getElementById('userPosts');
    try {
        const result = await api.get(`/api/posts?user_id=${userId}`);
        const posts = result.data;

        document.getElementById('postCount').textContent = posts.length;

        if (posts.length === 0) {
            container.innerHTML = '<div class="glass-card" style="text-align: center; color: var(--text-secondary); padding: 3rem;">还没有发布过帖子</div>';
            return;
        }

        container.innerHTML = '';
        posts.forEach(post => {
            const card = document.createElement('article');
            card.className = 'glass-card';
            card.style.cursor = 'pointer';
            card.onclick = () => window.location.href = `/post/${post.id}`;

            const aiBadge = post.has_ai ? '🤖 1' : '0';

            card.innerHTML = `
                <div style="margin-bottom: 0.5rem; display:flex; justify-content:space-between;">
                    <span class="text-sm font-bold text-gradient">#${post.tags && post.tags.length > 0 ? post.tags[0] : 'General'}</span>
                    <span class="text-sm text-muted">${post.created_at}</span>
                </div>
                <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">${post.title}</h3>
                <div style="display: flex; gap: 10px; margin-top: 1rem; align-items:center;">
                    <span class="text-sm text-muted">💬 ${post.comments_count} (${aiBadge})</span>
                    <span class="text-sm text-muted">👍 ${post.likes || 0}</span>
                    <button class="btn btn-outline btn-sm delete-btn" style="margin-left:auto; border-color: #ff4d4f; color: #ff4d4f;" data-id="${post.id}">删除</button>
                </div>
            `;

            // Handle delete button click separately to prevent card click
            const deleteBtn = card.querySelector('.delete-btn');
            deleteBtn.onclick = async (e) => {
                e.stopPropagation();
                if (confirm('确定要删除这条帖子吗？')) {
                    await deletePost(post.id);
                }
            };

            container.appendChild(card);
        });

    } catch (error) {
        console.error(error);
        container.innerHTML = '<div class="glass-card" style="color: var(--error); text-align: center;">加载失败</div>';
    }
}

async function deletePost(postId) {
    try {
        await api.delete(`/api/posts/${postId}`);
        alert('删除成功');
        // Reload posts
        const userStr = localStorage.getItem('osi_user');
        if (userStr) {
            const user = JSON.parse(userStr);
            loadUserPosts(user.id);
        }
    } catch (error) {
        alert('删除失败: ' + error.message);
    }
}
