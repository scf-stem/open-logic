document.addEventListener('DOMContentLoaded', () => {
    const modal = document.getElementById('scf-code-runner-modal');
    const closeBtn = document.getElementById('close-runner-modal');
    const runBtn = document.getElementById('run-code-btn');
    const langSelect = document.getElementById('code-runner-lang');
    const editor = document.getElementById('code-editor');
    const terminal = document.getElementById('terminal-output');
    
    const diagContainer = document.getElementById('diagnosis-container');
    const diagLayer1 = document.getElementById('diag-layer-1');
    const diagLayer2 = document.getElementById('diag-layer-2');
    const diagLayer3 = document.getElementById('diag-layer-3');
    const metricsBar = document.getElementById('metrics-bar');

    // Default templates based on language selection
    const templates = {
        'python': 'def squares(n):\n    return [i**2 for i in range(n) if i % 2 == 0]\n\nprint(squares(5))',
        'c': '#include <stdio.h>\n\nint* dangling() {\n    int local = 42;\n    return &local;\n}\n\nint main() {\n    int *p = dangling();\n    printf("%d\\n", *p);\n    return 0;\n}'
    };

    // Initialize Editor
    editor.value = templates[langSelect.value];

    langSelect.addEventListener('change', (e) => {
        editor.value = templates[e.target.value];
        clearTerminal();
    });

    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });
    
    // Close when clicking outside modal
    modal.addEventListener('click', (e) => {
        if(e.target === modal) {
            modal.style.display = 'none';
        }
    });

    function clearTerminal() {
        terminal.innerHTML = '<div class="terminal-placeholder">准备就绪...</div>';
        diagContainer.classList.add('hidden');
        metricsBar.classList.add('hidden');
    }

    runBtn.addEventListener('click', async () => {
        const code = editor.value;
        const lang = langSelect.value;
        
        runBtn.disabled = true;
        runBtn.textContent = '运行中...';
        clearTerminal();
        terminal.innerHTML = '正在编译执行...';

        try {
            const response = await fetch('/api/run', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ code, language: lang })
            });
            
            const result = await response.json();
            renderResult(result);
        } catch (err) {
            terminal.innerHTML = `<span class="error">网络错误或服务器异常: ${err.message}</span>`;
        } finally {
            runBtn.disabled = false;
            runBtn.textContent = '▶ 运行';
        }
    });

    function renderResult(result) {
        terminal.innerHTML = '';
        if (result.error) {
            terminal.innerHTML = `<span class="error">${result.error}</span>`;
            return;
        }

        const { execution = {}, analysis = {}, metrics = {} } = result;

        // 1. Render Terminal Output
        if (execution.stdout) {
            const outDiv = document.createElement('div');
            outDiv.textContent = execution.stdout;
            terminal.appendChild(outDiv);
        }
        if (execution.stderr) {
            const errDiv = document.createElement('div');
            errDiv.className = 'error';
            errDiv.textContent = execution.stderr;
            terminal.appendChild(errDiv);
        }
        
        if (execution.status === 'success') {
            const statusDiv = document.createElement('div');
            statusDiv.className = 'success';
            statusDiv.textContent = '\\n[程序正常退出, return code 0]';
            terminal.appendChild(statusDiv);
        } else if (execution.exit_code !== undefined) {
            const statusDiv = document.createElement('div');
            statusDiv.className = 'error';
            statusDiv.textContent = `\\n[执行失败，Exit Code: ${execution.exit_code}]`;
            terminal.appendChild(statusDiv);
        }

        // 2. Render SCF Diagnostics
        if (analysis.correctness === false && analysis.diagnosis) {
            diagContainer.classList.remove('hidden');
            const diag = analysis.diagnosis;
            
            // Layer 1
            if (diag.layer_1_instant) {
                diagLayer1.innerHTML = `<strong>${diag.layer_1_instant.headline}</strong>: ${diag.layer_1_instant.one_liner || ''}`;
                diagLayer1.classList.remove('hidden');
            } else {
                diagLayer1.classList.add('hidden');
            }

            // Layer 2
            if (diag.layer_2_deep) {
                diagLayer2.innerHTML = `<strong>深度解析 (${diag.layer_2_deep.error_category})</strong>: 此区域未来可嵌入AST可视化或栈生命周期图表。`;
                diagLayer2.classList.remove('hidden');
            } else {
                diagLayer2.classList.add('hidden');
            }

            // Layer 3
            if (diag.layer_3_resources) {
                diagLayer3.innerHTML = `<strong>修复建议</strong>: 请查阅相关文档以修复此安全或逻辑漏洞。`;
                diagLayer3.classList.remove('hidden');
            } else {
                diagLayer3.classList.add('hidden');
            }
        } else if (analysis.suggestion) {
            diagContainer.classList.remove('hidden');
            diagLayer1.innerHTML = `<strong>智能建议</strong>: ${analysis.suggestion.message}`;
            diagLayer1.classList.add('success');
            diagLayer1.classList.remove('hidden');
            diagLayer2.classList.add('hidden');
            diagLayer3.classList.add('hidden');
        } else {
            diagContainer.classList.add('hidden');
        }

        // 3. Render Metrics
        if (Object.keys(metrics).length > 0) {
            metricsBar.classList.remove('hidden');
            metricsBar.innerHTML = '';
            if (metrics.time_ms !== undefined) {
                 metricsBar.innerHTML += `<span>执行耗时: ${metrics.time_ms} ms</span>`;
            }
            if (metrics.compile_ms !== undefined) {
                 metricsBar.innerHTML += `<span>编译耗时: ${metrics.compile_ms} ms</span>`;
            }
            if (metrics.memory_kb !== undefined) {
                 metricsBar.innerHTML += `<span>内存峰值: ${metrics.memory_kb} KB</span>`;
            }
        } else {
            metricsBar.classList.add('hidden');
        }
    }
});
