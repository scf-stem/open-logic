// Home View Logic

document.addEventListener('DOMContentLoaded', () => {
    loadPosts('all');

    // Filter Logic (replaces setupTabs function call)
    const tabs = document.querySelectorAll('.tab-item');
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            tab.classList.add('active');
            loadPosts(tab.dataset.tag);
        });
    });

    // Typing Effect
    const el1 = document.getElementById('type-text-1');
    const el2 = document.getElementById('type-text-2');
    
    if (el1 && el2) {
        const text1 = "学习开源技术，";
        const text2 = "不再孤单";

        async function typeWriter(text, element) {
            for (let i = 0; i < text.length; i++) {
                element.textContent += text.charAt(i);
                await new Promise(r => setTimeout(r, 150)); // Typing speed
            }
        }

        async function startTyping() {
            // Wait a little before starting the first loop to show the initial fully rendered text
            await new Promise(r => setTimeout(r, 2000));
            while (true) { // Infinite loop
                // Clear text but keep zero-width space to maintain height
                el1.textContent = '\u200B';
                el2.textContent = '\u200B';

                await new Promise(r => setTimeout(r, 500)); // Initial delay
                await typeWriter(text1, el1);
                
                // Small pause between the two lines
                await new Promise(r => setTimeout(r, 300)); 
                await typeWriter(text2, el2);

                // Wait before restarting
                await new Promise(r => setTimeout(r, 4000));
            }
        }

        startTyping();
    }
});

// The setupTabs function is no longer needed as its logic has been moved into DOMContentLoaded
// function setupTabs() {
//     const tabs = document.querySelectorAll('.tab-item');
//     tabs.forEach(tab => {
//         tab.addEventListener('click', () => {
//             // Remove active class
//             tabs.forEach(t => t.classList.remove('active'));
//             // Add active class
//             tab.classList.add('active');

//             const tag = tab.dataset.tag;
//             loadPosts(tag);
//         });
//     });
// }

async function loadPosts(tag) {
    const container = document.getElementById('postsContainer');
    container.innerHTML = '<div style="grid-column:1/-1; text-align:center; padding:2rem;">加载中...</div>';

    try {
        let url = '/api/posts';
        if (tag && tag !== 'all') {
            url += `?tag=${tag}`;
        }

        const response = await fetch(url);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const result = await response.json();
        renderPosts(result.data, container);

    } catch (error) {
        console.error('Failed to load posts:', error);
        container.innerHTML = '<div style="color:var(--danger-color); text-align:center;">加载失败，请稍后重试</div>';
    }
}

function renderPosts(posts, container) {
    container.innerHTML = '';

    if (!posts || posts.length === 0) {
        container.innerHTML = '<div style="text-align:center; color:var(--text-secondary); grid-column: 1/-1; padding: 2rem;">没有找到相关帖子</div>';
        return;
    }

    posts.forEach(post => {
        const card = document.createElement('article');
        card.className = 'glass-card';
        card.style.cursor = 'pointer';
        card.style.border = '1px solid #E2E8F0';
        card.style.padding = '1.25rem';
        card.style.borderRadius = '12px';
        card.style.marginBottom = '1rem';
        card.style.background = '#FAFBFC';
        card.onclick = () => window.location.href = `/post/${post.id}`;

        const aiBadge = post.has_ai ? '🤖 1' : '0';

        card.innerHTML = `
            <div style="margin-bottom: 0.5rem;">
                <span class="text-sm font-bold text-gradient">#${post.tags && post.tags.length > 0 ? post.tags[0] : 'General'}</span>
                <span class="text-sm text-muted" style="float: right;">${post.created_at}</span>
            </div>
            <h3 style="font-size: 1.2rem; margin-bottom: 0.5rem;">${post.title}</h3>
            <p class="text-muted text-sm" style="margin-bottom: 1rem;">
                ${post.content.substring(0, 100)}...
            </p>
            <div style="display: flex; justify-content: space-between; align-items: center;">
                <div class="user-info" style="display: flex; gap: 5px; align-items: center;">
                    <div class="user-avatar" style="width: 24px; height: 24px; font-size: 0.7rem;">${post.author[0]}</div>
                    <span class="text-sm">${post.author}</span>
                </div>
                <div class="meta" style="display: flex; gap: 10px;">
                    <span class="text-sm text-muted">💬 ${post.comments_count} (${aiBadge})</span>
                </div>
            </div>
        `;
        container.appendChild(card);
    });
}
