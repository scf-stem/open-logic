// Post Detail Interactions

function getAuthHeader() {
    let token = '';
    const userJsonStr = localStorage.getItem('osi_user');
    if (userJsonStr) {
        try {
            const user = JSON.parse(userJsonStr);
            token = user.token || '';
        } catch (e) {}
    }
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    return headers;
}

document.addEventListener('DOMContentLoaded', () => {
    // Extract post ID from URL: /post/<id>
    const pathParts = window.location.pathname.split('/');
    const postId = pathParts[pathParts.length - 1];

    if (postId) {
        loadPostDetail(postId);
    }
});

async function loadPostDetail(postId) {
    const container = document.querySelector('.detail-container');
    // Simple check to ensure we are on the right page structure
    if (!container) return;

    try {
        const response = await fetch(`/api/posts/${postId}`, {
            method: 'GET',
            headers: getAuthHeader()
        });

        if (!response.ok) throw new Error('Failed to load post');
        
        const result = await response.json();
        const post = result.data;
        renderPostDetail(post, container);
    } catch (error) {
        console.error('Failed to load post:', error);
        container.innerHTML = '<div class="tech-card" style="text-align:center; color:#FF5555;">加载帖子失败，可能帖子不存在或已被删除。</div>';
    }
}

function renderPostDetail(post, container) {
    const aiComments = post.comments.filter(c => c.is_ai);
    // The first AI comment is the "Main Answer"
    const mainAiAnswer = aiComments.length > 0 ? aiComments[0] : null;
    // Subsequent AI comments are treated as replies in the discussion
    const aiReplies = aiComments.length > 1 ? aiComments.slice(1) : [];

    // Combine user comments and AI replies, sort by creation time
    const discussionComments = [...post.comments.filter(c => !c.is_ai), ...aiReplies].sort((a, b) => {
        return new Date(a.created_at) - new Date(b.created_at);
    });

    // 1. Render Question
    let html = `
        <article class="tech-card">
            <div class="post-meta">
                <span class="tech-tag">#${post.tags && post.tags.length > 0 ? post.tags[0] : 'General'}</span>
                <span class="meta-text">${post.author} 发布于 • ${post.created_at}</span>
            </div>
            
            <h1 class="post-title">${post.title}</h1>
            
            <div class="post-body">
                ${marked.parse(post.content)}
            </div>

            <div class="action-bar">
                <button id="likeBtn" onclick="likePost(${post.id})" class="btn-outline">👍 有用 (${post.likes || 0})</button>
                <button class="btn-outline" onclick="document.getElementById('replyContent').focus()">💬 评论</button>
            </div>
        </article>
    `;

    // 2. Render AI Answer (if exists)
    if (mainAiAnswer) {
        const aiAnswer = mainAiAnswer;
        html += `
        <div class="ai-card">
            <div class="ai-header">
                <div class="ai-badge">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
                    AI 智能解答路线
                </div>
                <span class="meta-text">即刻生成</span>
            </div>
            
            <div class="ai-content">
                ${marked.parse(aiAnswer.content)}
            </div>
            
            <div class="ai-feedback">
                <span class="meta-text" style="font-weight: 500;">这个解答有帮助吗？</span>
                <button class="btn-outline" style="padding: 0.3rem 0.8rem; font-size: 0.85rem; border-radius: 6px;">👍 是</button>
                <button class="btn-outline" style="padding: 0.3rem 0.8rem; font-size: 0.85rem; border-radius: 6px;">👎 否</button>
            </div>
        </div>
        `;
    }

    // 3. Render Discussion
    html += `<h3 class="section-title">${discussionComments.length} 条社区讨论</h3>
             <div class="tech-card" style="padding: 1.5rem 2.5rem;">
                 <div class="comment-list">`;

    if (discussionComments.length === 0) {
        html += '<p class="meta-text" style="text-align: center; margin: 2rem 0;">暂无探讨，快来抢沙发吧！</p>';
    } else {
        discussionComments.forEach(comment => {
            const isAi = comment.is_ai;
            html += `
            <div class="comment-item">
                <div class="comment-header">
                    <div class="user-wrap">
                        <div class="avatar-sm" ${isAi ? 'style="background: linear-gradient(135deg, #6C5CE7, #4834D4);"' : ''}>
                            ${isAi ? '🤖' : comment.author[0]}
                        </div>
                        <span class="comment-author">${isAi ? 'AI 助手 (互动)' : comment.author}</span>
                    </div>
                    <span class="comment-time">${comment.created_at}</span>
                </div>
                <div class="comment-text">
                    ${isAi ? marked.parse(comment.content) : comment.content.replace(/\n/g, '<br>')}
                </div>
            </div>
            `;
        });
    }
    html += `    </div>
             </div>`;

    // 4. Reply Box
    html += `
        <div class="tech-card">
            <h4 class="section-title" style="font-size: 1.2rem; margin-bottom: 1rem;">撰写回复</h4>
            <textarea id="replyContent" class="reply-area" rows="4" placeholder="在此分享你的见解，支持 Markdown..."></textarea>
            <div style="text-align: right;">
                <button onclick="submitReply(${post.id})" class="btn-primary">提交回复 ↗</button>
            </div>
        </div>
    `;

    container.innerHTML = html;
}

async function submitReply(postId) {
    const content = document.getElementById('replyContent').value;
    if (!content) return alert('请输入内容');

    try {
        const response = await fetch(`/api/posts/${postId}/comments`, {
            method: 'POST',
            headers: getAuthHeader(),
            body: JSON.stringify({ content })
        });

        if (!response.ok) {
            if (response.status === 401) {
                window.location.href = '/login';
                return;
            }
            throw new Error('提交失败');
        }

        // alert('提交成功'); <-- Skipping native alert in favor of quiet reload or minimal UI
        loadPostDetail(postId); // Reload
    } catch (error) {
        alert('提交失败: ' + error.message);
    }
}

async function likePost(postId) {
    try {
        const response = await fetch(`/api/posts/${postId}/like`, {
            method: 'POST',
            headers: getAuthHeader()
        });

        if (!response.ok) {
            if (response.status === 401) window.location.href = '/login';
            throw new Error('Action failed');
        }

        const result = await response.json();
        const btn = document.getElementById('likeBtn');
        btn.innerHTML = `👍 有用 (${result.likes})`;
        btn.classList.add('btn-primary'); // Highlight selected
        btn.classList.remove('btn-outline');
    } catch (error) {
        console.error(error);
    }
}
