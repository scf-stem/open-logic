// Auth View Logic

function showAuthMessage(form, message, isError = true) {
    // Remove existing
    const existing = form.querySelector('.auth-msg-banner');
    if (existing) existing.remove();

    const banner = document.createElement('div');
    banner.className = `auth-msg-banner ${isError ? 'error' : 'success'}`;
    banner.style.padding = '0.75rem';
    banner.style.marginBottom = '1.5rem';
    banner.style.borderRadius = '8px';
    banner.style.fontSize = '0.9rem';
    banner.style.textAlign = 'center';
    banner.style.background = isError ? 'rgba(255, 60, 60, 0.1)' : 'rgba(0, 212, 170, 0.1)';
    banner.style.color = isError ? '#FF5555' : '#00D4AA';
    banner.style.border = `1px solid ${isError ? 'rgba(255, 60, 60, 0.2)' : 'rgba(0, 212, 170, 0.2)'}`;
    banner.innerText = message;

    // Insert before the submit button
    const submitBtn = form.querySelector('button[type="submit"]');
    form.insertBefore(banner, submitBtn);
}

const authForm = document.getElementById('authForm');
const registerForm = document.getElementById('registerForm');

if (authForm) {
    authForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const submitBtn = this.querySelector('button[type="submit"]');

        // Optional HTML5 validation override
        if (!username || !password) {
            showAuthMessage(this, '请输入用户名和密码');
            return;
        }

        try {
            submitBtn.disabled = true;
            submitBtn.innerText = '登录中...';

            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password })
            });

            if (!response.ok) {
                const errData = await response.json();
                throw new Error(errData.message || `HTTP error! status: ${response.status}`);
            }

            const result = await response.json();

            // Save user info
            localStorage.setItem('osi_user', JSON.stringify(result.data));

            showAuthMessage(this, '登录成功！即将跳转...', false);
            setTimeout(() => {
                window.location.href = '/';
            }, 800);

        } catch (error) {
            showAuthMessage(this, '登录失败: ' + (error.message || '用户名或密码错误'));
            submitBtn.disabled = false;
            submitBtn.innerText = '登 录';
            console.error(error);
        }
    });
}

if (registerForm) {
    // Captcha Refresh
    const captchaImg = document.getElementById('captchaImg');
    if (captchaImg) {
        captchaImg.onclick = function () {
            this.src = '/api/auth/captcha?t=' + new Date().getTime();
        };
    }

    registerForm.addEventListener('submit', async function (e) {
        e.preventDefault();

        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const captcha = document.getElementById('captcha').value;
        const submitBtn = this.querySelector('button[type="submit"]');

        if (!username || !password || !captcha) {
            showAuthMessage(this, '请填写所有必填项');
            return;
        }

        try {
            submitBtn.disabled = true;
            submitBtn.innerText = '注册中...';

            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username, password, captcha })
            });

            const data = await response.json();

            if (!response.ok) {
                // If the response is not ok, trigger an error
                throw new Error(data.message || `HTTP error! status: ${response.status}`);
            }

            showAuthMessage(this, '注册成功！正在前往登录...', false);
            
            setTimeout(() => {
                window.location.href = '/login';
            }, 1200);

        } catch (error) {
            showAuthMessage(this, '注册失败: ' + (error.message || '请重试'));
            
            // Refresh captcha on failure automatically
            if (captchaImg) captchaImg.click();
            document.getElementById('captcha').value = '';

            submitBtn.disabled = false;
            submitBtn.innerText = '创建账号';
            console.error(error);
        }
    });
}
