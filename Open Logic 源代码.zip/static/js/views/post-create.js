// Post Create View Logic

function showPostMessage(form, message, isError = true) {
    const existing = form.querySelector('.auth-msg-banner');
    if (existing) existing.remove();

    const banner = document.createElement('div');
    banner.className = `auth-msg-banner ${isError ? 'error' : 'success'}`;
    banner.style.padding = '0.75rem';
    banner.style.marginBottom = '1.5rem';
    banner.style.borderRadius = '8px';
    banner.style.fontSize = '0.9rem';
    banner.style.textAlign = 'center';
    banner.style.background = isError ? 'rgba(255, 60, 60, 0.1)' : 'rgba(0, 212, 170, 0.1)';
    banner.style.color = isError ? '#FF5555' : '#00D4AA';
    banner.style.border = `1px solid ${isError ? 'rgba(255, 60, 60, 0.2)' : 'rgba(0, 212, 170, 0.2)'}`;
    banner.innerText = message;

    const submitBtn = form.querySelector('.btn-group');
    form.insertBefore(banner, submitBtn);
}

document.getElementById('postForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const title = document.getElementById('title').value.trim();
    const content = document.getElementById('content').value.trim();
    const tags = document.getElementById('tags').value;

    const submitBtn = this.querySelector('button[type="submit"]');
    const originalText = submitBtn.innerText;

    if (!title) {
        showPostMessage(this, '请输入探讨主题', true);
        return;
    }

    if (!content) {
        showPostMessage(this, '请输入详细上下文', true);
        return;
    }
    
    if (!tags) {
        showPostMessage(this, '请选择一个标签', true);
        return;
    }

    try {
        submitBtn.disabled = true;
        submitBtn.classList.add('loading');
        
        let token = '';
        const userJsonStr = localStorage.getItem('osi_user');
        if (userJsonStr) {
            try {
                const user = JSON.parse(userJsonStr);
                token = user.token || ''; // Attempt to grab token if it exists
            } catch (e) {}
        }

        const headers = { 'Content-Type': 'application/json' };
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const response = await fetch('/api/posts', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ title, content, tags })
        });

        if (!response.ok) {
            if (response.status === 401) {
                showPostMessage(this, '请先登录后再发布！正在跳转...');
                setTimeout(() => window.location.href = '/login', 1500);
                return;
            }
            const errData = await response.json().catch(() => ({}));
            throw new Error(errData.message || `HTTP error! status: ${response.status}`);
        }

        showPostMessage(this, '发布成功！正在跳转至首页...', false);
        setTimeout(() => {
            window.location.href = '/#posts';
        }, 1200);

    } catch (error) {
        showPostMessage(this, '发布失败，' + (error.message || '请重试'));
        submitBtn.disabled = false;
        submitBtn.classList.remove('loading');
        console.error(error);
    }
});
