# OSI Tutor (源问)

**OSI Tutor (源问)** 是一个面向青少年的 AI 增强型开源技术学习社区。本项目旨在解决偏远地区学生在学习编程与开源硬件时遇到的资源匮乏和答疑延迟问题。通过集成 AI 智能助手，实现“即问即答”，并结合社区互助，让每一个问题都有回响。

## ✨ 核心功能

*   **社区问答**: 支持 Markdown 的提问与回答系统，用户可以交流 Python, Arduino, Web 开发等技术问题。
*   **AI 智能助手**: 集成 OpenAI GPT-4o 模型，自动为新问题生成友好的参考答案，提供即时指导。
*   **青少年友好 UI**: 采用流行的“玻璃拟态 (Glassmorphism)”设计风格，界面现代、活泼。
*   **用户系统**: 包含注册、登录及个人身份管理。

## 🛠 技术栈

*   **前端**: HTML5, CSS3 (Vanilla), JavaScript (原生 ES6+)
*   **后端**: Python Flask 3.x
*   **数据库**: SQLite (通过 SQLAlchemy ORM 管理)
*   **AI 接口**: OpenAI API

## 🚀 快速开始

### 1. 环境准备

确保您的系统已安装 Python 3.9 或以上版本。

### 2. 安装依赖

建议使用虚拟环境运行本项目：

```bash
# 创建虚拟环境
python3 -m venv venv

# 激活虚拟环境 (macOS/Linux)
source venv/bin/activate

# 激活虚拟环境 (Windows)
# venv\Scripts\activate

# 安装项目依赖
pip install -r requirements.txt
```

### 3. 配置环境变量

本项目使用 **DeepSeek API** (OpenAI 兼容接口) 提供智能回答功能。请在终端设置您的 API Key：

```bash
# macOS/Linux
export OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Windows (CMD)
set OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

> **注意**: 项目默认使用 DeepSeek 官方接口 `https://api.deepseek.com`。如需使用其他 OpenAI 兼容服务，可设置 `OPENAI_BASE_URL` 环境变量。

### 4. 运行项目

初始化数据库并启动开发服务器：

```bash
python3 app.py
```

终端显示如下信息即表示启动成功：
```text
Starting OSI Tutor Server at http://127.0.0.1:8080
```

### 5. 访问应用

打开浏览器访问：[http://127.0.0.1:8080](http://127.0.0.1:8080)

## 📂 项目结构

```text
OSI_Tutor/
├── app.py              # 应用入口 (Flask App)
├── config.py           # 配置文件
├── extensions.py       # 扩展初始化 (DB, Migrate等)
├── models/             # 数据库模型 (User, Post, Comment)
├── routes/             # 路由蓝图 (Auth, Posts, Comments)
├── services/           # 服务层 (AI Service)
├── static/             # 静态资源 (CSS, JS)
├── templates/          # HTML 模板
└── requirements.txt    # 依赖列表
```

## 📝 贡献指南

本项目为 Technovation Girls 参赛演示项目。欢迎提交 Issue 或 Pull Request 进行改进。

---
Created by OSI Tutor Team.
