"use client";

import { useState } from "react";
import Editor from "@monaco-editor/react";

export default function RunnerPage() {
  const [language, setLanguage] = useState("python");
  const [code, setCode] = useState("def squares(n):\n    return [i**2 for i in range(n) if i % 2 == 0]\n\nprint(squares(5))");
  const [output, setOutput] = useState("");
  const [status, setStatus] = useState("idle");

  const runCode = async () => {
    setStatus("running");
    setOutput("Executing Code in Enterprise Sandbox...");
    
    try {
      const response = await fetch("http://127.0.0.1:8080/runner/execute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ language, code }),
      });

      const data = await response.json();
      
      setStatus(data.execution?.status === "success" ? "success" : "error");
      
      let outStr = "";
      if (data.execution?.stdout) outStr += `> ${data.execution.stdout}\n`;
      if (data.execution?.stderr) outStr += `[STDERR]\n${data.execution.stderr}\n`;
      if (data.analysis?.suggestion?.message) {
         outStr += `\n[诊断输出]\n${data.analysis.suggestion.message}`;
      }
      
      setOutput(outStr || "执行完毕，无输出。");
    } catch (err) {
      setStatus("error");
      setOutput(`网络错误或沙箱服务不可用: ${err}`);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header Panel */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card text-card-foreground">
        <div className="flex items-center gap-4">
          <button className="text-sm font-medium hover:text-primary">&larr; 返回源问首页</button>
          <h1 className="text-xl font-bold ml-4 border-l pl-4 border-border">代码运行器</h1>
        </div>
        <div className="flex items-center gap-3">
          <select 
            className="bg-background border border-border text-sm rounded-md px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary"
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
          >
            <option value="python">Python 3.11</option>
            <option value="c">C (GCC 11)</option>
          </select>
          <button 
            onClick={runCode}
            disabled={status === "running"}
            className="bg-primary text-primary-foreground hover:bg-primary/90 px-4 py-1.5 rounded-md text-sm font-medium flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            {status === "running" ? "Running..." : "运行 ▶"}
          </button>
        </div>
      </header>

      {/* Main IDE area */}
      <div className="flex flex-1 overflow-hidden">
        {/* File Explorer */}
        <aside className="w-64 border-r border-border bg-muted/30 flex flex-col">
          <div className="p-3 font-semibold text-sm border-b border-border text-muted-foreground uppercase tracking-wider">资源管理器</div>
          <div className="p-2 flex-1 overflow-y-auto">
            <div className="px-3 py-1.5 text-sm hover:bg-card cursor-pointer rounded-md flex items-center gap-2 font-medium">
              📁 main.py
            </div>
            <div className="px-3 py-1.5 text-sm hover:bg-card cursor-pointer rounded-md flex items-center gap-2 text-muted-foreground">
              📄 utils.c
            </div>
            <div className="px-3 py-2 text-primary text-sm hover:underline cursor-pointer mt-2">
              [+] 新建文件
            </div>
          </div>
        </aside>

        {/* Editor Area */}
        <main className="flex-1 border-r border-border flex flex-col bg-card">
          <div className="flex bg-muted/50 border-b border-border items-center">
            <div className="px-4 py-2 text-sm bg-card border-r border-border font-medium">main.py</div>
            <div className="px-4 py-2 text-sm text-muted-foreground hover:bg-card/50 cursor-pointer">utils.c</div>
          </div>
          <div className="flex-1 relative">
            <Editor
              height="100%"
              theme="vs-dark" // Will dynamic swap if implementing full dark mode
              language={language}
              value={code}
              onChange={(val) => setCode(val || "")}
              options={{
                minimap: { enabled: false },
                fontSize: 14,
                fontFamily: "var(--font-mono)",
                padding: { top: 16 }
              }}
            />
          </div>
        </main>

        {/* Output & Diagnosics Side Panel */}
        <aside className="w-80 bg-card flex flex-col border-l border-border">
          <div className="flex border-b border-border">
            <button className="flex-1 py-2 text-sm font-medium bg-background border-b-2 border-primary text-primary">输出</button>
            <button className="flex-1 py-2 text-sm font-medium text-muted-foreground hover:bg-muted/50">性能</button>
            <button className="flex-1 py-2 text-sm font-medium text-muted-foreground hover:bg-muted/50">调试</button>
          </div>
          
          <div className="flex-1 p-4 overflow-y-auto">
            <div className="font-mono text-sm whitespace-pre-wrap text-foreground mb-6 bg-muted/30 p-3 rounded border border-border">
              {output || "等待运行..."}
            </div>

            {status === "success" && (
              <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4">
                <div className="border border-border rounded-lg p-3 bg-primary/5">
                  <h4 className="font-semibold text-sm mb-2 text-primary">💡 优化建议</h4>
                  <ul className="text-sm space-y-2 text-muted-foreground list-disc pl-4">
                    <li>使用 <code className="text-secondary-foreground font-semibold">生成器</code> 节省内存 (O(n) &rarr; O(1))</li>
                    <li>增加类型提示增强可读性</li>
                  </ul>
                </div>

                <button className="w-full py-2 border border-border rounded-md text-sm font-medium hover:bg-muted transition-colors flex items-center justify-center gap-2">
                  同步到源问进度 ▼
                </button>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
