"use client";

import { useState } from "react";

export default function LearningPage() {
  const [activeTrack, setActiveTrack] = useState<"python" | "c" | "vibe">("vibe");

  return (
    <div className="flex flex-col h-screen bg-background text-foreground">
      {/* Header Panel */}
      <header className="flex items-center justify-between px-4 py-3 border-b border-border bg-card text-card-foreground">
        <div className="flex items-center gap-4">
          <button className="text-sm font-medium hover:text-primary">&larr; 返回源问首页</button>
          <h1 className="text-xl font-bold ml-4 border-l pl-4 border-border">多语言学习</h1>
        </div>
        <div className="flex items-center gap-3">
          <select 
            className="bg-background border border-border text-sm rounded-md px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-primary"
            value={activeTrack}
            onChange={(e) => setActiveTrack(e.target.value as "python" | "c" | "vibe")}
          >
            <option value="python">Python 数据思维</option>
            <option value="c">C 系统思维</option>
            <option value="vibe">Vibe Coding (AI协作)</option>
          </select>
          <button className="bg-secondary text-secondary-foreground hover:bg-secondary/80 px-4 py-1.5 rounded-md text-sm font-medium transition-colors">
            学习档案
          </button>
        </div>
      </header>

      {/* Track Stats Bar */}
      <div className="bg-muted/30 border-b border-border px-6 py-2 flex justify-between items-center text-sm">
        <div className="flex space-x-6 font-medium text-muted-foreground">
          <span className={activeTrack === 'python' ? 'text-primary' : ''}>Python 数据思维</span>
          <span>|</span>
          <span className={activeTrack === 'c' ? 'text-primary' : ''}>C 系统思维</span>
          <span>|</span>
          <span className={activeTrack === 'vibe' ? 'text-primary' : ''}>Vibe Coding</span>
        </div>
        <div className="flex gap-4 items-center">
          <span className="text-muted-foreground">当前进度：</span>
          <strong className="text-primary font-bold">68%</strong>
          <span className="text-muted-foreground ml-4">预计剩余：12小时</span>
        </div>
      </div>

      {/* Main Learning Content Area */}
      <div className="flex flex-1 overflow-hidden">
        {/* Navigation / Course Map Sidebar */}
        <aside className="w-72 border-r border-border bg-card flex flex-col p-4 overflow-y-auto">
          <h3 className="font-bold text-lg mb-4">课程地图导航</h3>
          
          {/* Node visualization mockup */}
          <div className="relative pl-6 space-y-8 before:absolute before:inset-y-0 before:-ml-px before:w-0.5 before:bg-border mb-8">
            <div className="relative">
              <span className="absolute -left-[1.65rem] bg-green-500 rounded-full w-3 h-3 border-2 border-background ring-2 ring-background mt-1.5" />
              <div className="flex flex-col gap-1">
                <span className="text-sm font-bold text-foreground">基础</span>
                <span className="text-xs text-muted-foreground">已完成 ✓</span>
              </div>
            </div>
            <div className="relative">
              <span className="absolute -left-[1.65rem] bg-orange-500 rounded-full w-3 h-3 border-2 border-background ring-4 ring-orange-500/30 mt-1.5" />
              <div className="flex flex-col gap-1 border border-orange-500 bg-orange-500/5 p-2 rounded w-full">
                <span className="text-sm font-bold text-orange-600">进阶 (当前)</span>
                <span className="text-xs text-orange-600/80">进行中 ⏳</span>
              </div>
            </div>
            <div className="relative opacity-50">
              <span className="absolute -left-[1.65rem] bg-muted-foreground rounded-full w-3 h-3 border-2 border-background ring-2 ring-background mt-1.5" />
              <div className="flex flex-col gap-1">
                <span className="text-sm font-bold text-foreground">挑战</span>
                <span className="text-xs text-muted-foreground">锁定 🔒</span>
              </div>
            </div>
          </div>

          <div className="mt-auto pt-6 border-t border-border">
            <h4 className="font-semibold text-sm mb-2">路径推荐 (企业级引擎)</h4>
            <p className="text-xs text-muted-foreground bg-muted p-2 rounded">
              ↳ 完成本单元进阶练习后，将解锁：<strong className="text-primary">异步编程</strong> 模块
            </p>
          </div>
        </aside>

        {/* Dynamic Content Pane based on Track */}
        <main className="flex-1 p-6 overflow-y-auto bg-card">
          {activeTrack === "vibe" && <VibeCodingView />}
          {activeTrack === "python" && <PythonTrackView />}
          {activeTrack === "c" && <CTrackView />}
        </main>
      </div>
    </div>
  );
}

// Mockup component for Python View
function PythonTrackView() {
  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
        <h2 className="text-2xl font-bold tracking-tight mb-2">迭代器与惰性求值</h2>
        <p className="text-muted-foreground">目标：理解内存效率与计算延迟的权衡</p>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="border rounded-lg p-4 bg-muted/20 flex items-center justify-between">
          <span className="font-medium">▶️ 视频讲解</span>
          <span className="text-sm text-muted-foreground">3分钟</span>
        </div>
        <div className="border border-blue-200 rounded-lg p-4 bg-blue-50/50 flex items-center justify-between">
          <span className="font-medium text-blue-800">📊 交互式内存曲线对比</span>
          <span className="text-sm text-blue-600">已完成</span>
        </div>
      </div>
      
      <div className="border rounded-lg border-border bg-background shadow-sm p-6 space-y-4">
         <h3 className="font-bold text-lg border-b pb-2">进阶练习：自定义 Range 类</h3>
         <p className="text-sm">当前小节要求：使用 Python 魔法方法 <code className="bg-muted px-1 rounded text-red-500">__iter__</code> 与 <code className="bg-muted px-1 rounded text-red-500">__next__</code> 实现负步长支持。</p>
         <div className="bg-muted/40 p-4 font-mono text-sm rounded border">
            class ReverseRange:<br />
            &nbsp;&nbsp;def __init__(self, start, stop, step):<br />
            &nbsp;&nbsp;&nbsp;&nbsp;pass
         </div>
         <div className="flex gap-4 pt-4">
            <button className="bg-primary text-primary-foreground px-4 py-2 rounded-md text-sm font-medium hover:bg-primary/90">进入沙箱练习 &rarr;</button>
         </div>
      </div>
    </div>
  )
}

function CTrackView() {
   return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div>
         <div className="flex items-center gap-3 mb-2">
            <h2 className="text-2xl font-bold tracking-tight text-red-600">虚拟内存与页表机制</h2>
            <span className="bg-red-100 text-red-700 px-2 py-0.5 text-xs rounded border border-red-200 font-bold">安全实验室 🔒</span>
         </div>
        <p className="text-muted-foreground">企业级底层实验环境 · 实验室权限: 容器root (剩余时间 45min)</p>
      </div>

      <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm space-y-2 border border-border shadow-inner">
         <div className="text-white opacity-50 mb-4">// System Call Trap Simulation Visualization</div>
         <div>$ gcc -o test -fsanitize=address -fstack-protector test.c</div>
         <div>$ ./test</div>
         <div className="text-red-500 font-bold mt-4">
            ==31415==ERROR: AddressSanitizer: stack-buffer-overflow on address 0x7ffd<br />
            READ of size 4 at 0x7ffd thread T0
         </div>
      </div>

       <div className="grid grid-cols-2 gap-4">
        <div className="border rounded-lg p-4 justify-between space-y-2">
          <span className="font-bold block">实时内容布局图</span>
          <div className="bg-muted h-32 rounded border border-border flex flex-col justify-between p-2 text-xs font-mono">
            <div className="bg-purple-200 text-purple-800 p-1 text-center border-b border-purple-300">栈段 (Stack) &darr;</div>
            <div className="flex-1 border-x border-dashed border-gray-400 flex items-center justify-center text-gray-400">Heap / Mmap Area</div>
            <div className="bg-blue-200 text-blue-800 p-1 text-center border-t border-blue-300">堆段 (Heap) &uarr;</div>
          </div>
        </div>
        <div className="border rounded-lg p-4 justify-between space-y-2 bg-red-50/50 border-red-100">
           <span className="font-bold text-red-700 flex items-center gap-2"><span>⚠️</span> 安全事件拦截日志</span>
           <ul className="text-sm space-y-2 text-red-800/80 font-mono">
             <li>[10:23:44] WARN: attempt malloc() exceeding limits.</li>
             <li className="font-bold">[10:23:47] FATAL: seccomp_bpf blocked execve() syscall. Process terminated.</li>
           </ul>
        </div>
      </div>
    </div>
   )
}

function VibeCodingView() {
  const [checked1, setChecked1] = useState(false);
  const [checked2, setChecked2] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const canSubmit = checked1 && checked2;

  return (
    <div className="h-full flex flex-col">
      <div className="flex justify-between items-center mb-6">
        <div>
           <h2 className="text-2xl font-bold tracking-tight">提示工程与代码审查</h2>
           <p className="text-muted-foreground text-sm mt-1">企业级人机协作审计系统 · 认证进度：L1 &rarr; L2</p>
        </div>
        <div className="bg-green-100 text-green-800 px-3 py-1.5 rounded-full font-bold text-sm flex items-center gap-2">
           <span>⚕️</span> 协作健康度: {submitted ? '85/100 (+3)' : '82/100'}
        </div>
      </div>

      <div className="flex-1 grid grid-cols-5 gap-6 min-h-0">
        <div className="col-span-3 border rounded-lg bg-background shadow-sm flex flex-col min-h-0">
           {/* Intent input and Gen preview */}
           <div className="p-4 border-b border-border bg-muted/20 font-semibold flex justify-between items-center">
              <span>意图输入与协作预览</span>
              <span className="text-xs font-normal text-muted-foreground bg-background px-2 py-1 rounded border">对话轮次: 4</span>
           </div>
           
           <div className="flex-1 p-4 space-y-4 overflow-y-auto">
             <div className="flex flex-col gap-2 p-3 bg-blue-50 border border-blue-100 rounded-lg max-w-[85%] self-end ml-auto">
                <span className="text-xs text-blue-500 font-bold uppercase tracking-wider">人类意图</span>
                <p className="text-sm">"实现线程安全LRU缓存，支持并发读写，容量1000"</p>
                <div className="flex gap-2 mt-2 pt-2 border-t border-blue-200/50 text-xs">
                   <span className="bg-white px-1.5 py-0.5 rounded text-green-600">结构完整 8/10</span>
                   <span className="bg-white px-1.5 py-0.5 rounded text-orange-500">边界缺陷 6/10</span>
                </div>
             </div>

              <div className="flex flex-col gap-2 p-3 bg-muted/40 border border-border rounded-lg max-w-[90%]">
                <span className="text-xs text-muted-foreground font-bold uppercase tracking-wider">AI 生成预览</span>
                <pre className="text-xs bg-slate-900 text-slate-50 p-3 rounded font-mono overflow-x-auto">
{`import threading
from collections import OrderedDict

class ThreadSafeLRU:
    def __init__(self, capacity: int = 1000):
        self.capacity = capacity
        self.cache = OrderedDict()
        self._lock = threading.RLock() # ⚠️ Suggested Review`}
                </pre>
             </div>
           </div>

           <div className="p-4 border-t border-border bg-muted/10">
              <div className="flex gap-2">
                 <input type="text" placeholder="输入追加条件..." className="flex-1 border border-border rounded-md px-3 text-sm" />
                 <button className="bg-primary text-primary-foreground px-4 py-2 rounded text-sm font-medium">发送意图</button>
              </div>
           </div>
        </div>

        <div className="col-span-2 border border-orange-200 rounded-lg bg-orange-50/30 flex flex-col shadow-sm">
           <div className="p-4 border-b border-orange-200 bg-orange-100/50 text-orange-900 font-bold flex gap-2">
              <span>⚖️</span> 企业级代码所有权审计表
           </div>
           <div className="p-4 flex-1 space-y-4 overflow-y-auto">
              <div className="border border-orange-200 bg-white rounded shadow-sm text-sm">
                 <div className="grid grid-cols-[1fr_auto] gap-4 p-3 border-b border-orange-100 items-center">
                    <code className="text-xs text-gray-600 truncate">import threading</code>
                    <span className="text-green-600 font-bold text-xs bg-green-50 px-2 py-1 rounded">✓ 理性确认</span>
                 </div>
                 <div className="grid grid-cols-[1fr_auto] gap-4 p-3 border-b border-orange-100 items-center bg-orange-50">
                    <code className="text-xs text-orange-800 truncate">self._lock = threading.RLock()</code>
                    <span className={`font-bold text-xs px-2 py-1 rounded border ${submitted ? 'text-green-600 bg-green-50 border-green-200' : 'text-orange-600 bg-white border-orange-200'}`}>
                      {submitted ? '✓ 确认采用' : '？ 语义存疑'}
                    </span>
                 </div>
              </div>

              {!submitted ? (
                <div className="bg-white p-4 rounded border border-orange-200 mt-4 space-y-3">
                  <h4 className="font-bold text-sm text-gray-800">☑️ 合规声明签核</h4>
                  <label className="flex items-start gap-2 text-xs text-gray-700 cursor-pointer">
                      <input type="checkbox" className="mt-0.5" checked={checked1} onChange={(e) => setChecked1(e.target.checked)} />
                      我理解以上生成的代码语义，及 RLock 锁降级可能带来的死锁副作用。
                  </label>
                  <label className="flex items-start gap-2 text-xs text-gray-700 cursor-pointer">
                      <input type="checkbox" className="mt-0.5" checked={checked2} onChange={(e) => setChecked2(e.target.checked)} />
                      我验证过并发边界状态行为。
                  </label>
                  <button 
                    disabled={!canSubmit}
                    onClick={() => setSubmitted(true)}
                    className={`w-full mt-4 py-2 rounded text-sm font-bold transition-colors ${canSubmit ? 'bg-orange-600 text-white hover:bg-orange-700 shadow-md' : 'bg-orange-500 text-white opacity-50 cursor-not-allowed'}`}>
                      签署并接受变更 (需全选)
                  </button>
                </div>
              ) : (
                <div className="bg-green-50 text-green-800 p-4 rounded border border-green-200 mt-4 flex flex-col items-center justify-center py-6">
                  <span className="text-3xl mb-2">🎉</span>
                  <p className="font-bold">企业级合规申明已签署</p>
                  <p className="text-xs mt-1 text-green-700 text-center">当前代码变更已计入您的 L2 认证考核池<br/>继续努力！</p>
                </div>
              )}
           </div>
        </div>
      </div>
    </div>
  )
}
