/** @type {import('next').NextConfig} */
const nextConfig = {
  async rewrites() {
    return [
      {
        source: '/runner/:path*',
        destination: 'http://localhost:3001/:path*', // Proxy to runner app
      },
      {
        source: '/learning/:path*',
        destination: 'http://localhost:3002/:path*', // Proxy to learning app
      },
    ]
  },
}
export default nextConfig
