import { test, expect } from '@playwright/test';

test.describe('OSI Tutor Enterprise e2e tests', () => {
  test('Homepage has gateways to micro-frontends', async ({ page }) => {
    // Navigate to the Host application
    await page.goto('/');
    
    // Check for the core gateway links
    await expect(page.locator('text=代码运行器')).toBeVisible();
    await expect(page.locator('text=多语言学习')).toBeVisible();
  });

  test('Runner Micro-Frontend works and interacts with Sandbox', async ({ page }) => {
    // Navigate to proxied Runner App
    await page.goto('/runner');
    
    // Verify Editor loaded
    await expect(page.locator('text=返回源问首页')).toBeVisible();
    await expect(page.locator('text=代码运行器')).toBeVisible();
    
    // Select language & Execute
    const langSelect = page.locator('select');
    await langSelect.selectOption('python');
    
    const runBtn = page.locator('button:has-text("运行 ▶")');
    await runBtn.click();
    
    // Check Output Panel for Sandbox connection success
    // Depending on the sandbox API, it sends back the payload "执行成功" or the actual stdout
    await expect(page.locator('text=等待运行...')).not.toBeVisible();
    await expect(page.locator('text=> [0, 4, 16]')).toBeVisible({ timeout: 15000 });
  });

  test('Learning Micro-Frontend Vibe Coding Interactive Audit works', async ({ page }) => {
    // Navigate to proxied Learning App
    await page.goto('/learning');
    
    // Switch to Vibe Coding Track
    const trackSelect = page.locator('select');
    await trackSelect.selectOption('vibe');
    
    // Verify Vibe Coding View loaded
    await expect(page.locator('text=提示工程与代码审查')).toBeVisible();
    
    // Find checkboxes for Audit
    const checkboxes = page.locator('input[type="checkbox"]');
    await expect(checkboxes).toHaveCount(2);
    
    // The submit button should be disabled initially
    const submitBtn = page.locator('button:has-text("签署并接受变更")');
    await expect(submitBtn).toBeDisabled();
    
    // Check both boxes
    await checkboxes.nth(0).check();
    await checkboxes.nth(1).check();
    
    // Should be enabled now
    await expect(submitBtn).toBeEnabled();
    
    // Click submit
    await submitBtn.click();
    
    // Check success notification UI state
    await expect(page.locator('text=企业级合规申明已签署')).toBeVisible();
    await expect(page.locator('text=当前代码变更已计入您的 L2 认证考核池')).toBeVisible();
  });
});
