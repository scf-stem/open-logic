export default function Home() {
  return (
    <div className="container mx-auto py-6">
      <div className="flex gap-6 min-h-[calc(100vh-8rem)]">
        {/* 源问核心功能区主体内容区域（占比70%） */}
        <section className="flex-1 border rounded-lg p-6 bg-card text-card-foreground shadow-sm">
          <h2 className="text-2xl font-bold tracking-tight mb-4">【源问核心区】学习洞察与课程流</h2>
          <div className="space-y-4">
            <p className="text-muted-foreground">此处将通过 Module Federation 接入现有的源问功能：今日学习、我的课程、知识图谱等。</p>
            {/* Mocking Content Stream */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {[1, 2, 3].map((card) => (
                <div key={card} className="border rounded-md p-4 aspect-video flex flex-col items-center justify-center bg-muted/50">
                  <span className="text-lg font-medium text-muted-foreground">课程卡片 {card}</span>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* 新增功能入口侧边智能助手（占比30%） */}
        <aside className="w-[350px] space-y-4 shrink-0">
          <div className="border rounded-lg p-4 bg-primary/5 shadow-sm text-primary">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <span>🚀</span> 快速工具
            </h3>
            
            <div className="space-y-3">
              <a href="/runner" className="w-full flex-col block items-start text-left p-3 border rounded-md bg-card hover:bg-accent hover:text-accent-foreground transition-colors group">
                <div className="font-semibold flex items-center gap-2">
                  <span>⚡</span> 代码运行器
                </div>
                <div className="text-xs text-muted-foreground mt-1">Python · C 在线编译</div>
                <div className="text-xs text-blue-500 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">立即练习 →</div>
              </a>
              
              <a href="/learning" className="w-full flex-col block items-start text-left p-3 border rounded-md bg-card hover:bg-accent hover:text-accent-foreground transition-colors group">
                <div className="font-semibold flex items-center gap-2">
                  <span>📚</span> 多语言学习
                </div>
                <div className="text-xs text-muted-foreground mt-1">Py · C · Vibe Coding</div>
                <div className="text-xs text-blue-500 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">进入课程 →</div>
              </a>
            </div>
          </div>

          <div className="border rounded-lg p-4 bg-card text-card-foreground shadow-sm">
            <h3 className="font-semibold text-lg mb-3 flex items-center gap-2">
              <span>📊</span> 学习洞察 (模块集成)
            </h3>
            <ul className="space-y-2 text-sm">
              <li className="flex justify-between">
                <span className="text-muted-foreground">本周专注</span>
                <span className="font-medium">12小时</span>
              </li>
              <li className="flex justify-between">
                <span className="text-muted-foreground">连续学习</span>
                <span className="font-medium text-orange-500">5天 🔥</span>
              </li>
              <li className="flex justify-between">
                <span className="text-muted-foreground">技能成长</span>
                <span className="font-medium text-green-600">+15%</span>
              </li>
            </ul>
          </div>
        </aside>
      </div>
    </div>
  );
}
