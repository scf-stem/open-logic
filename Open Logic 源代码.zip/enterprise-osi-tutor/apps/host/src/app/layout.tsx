import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'OSI Tutor 源问 - 企业级计算机教育平台',
  description: '重构并引入智能微前端模块的全新源问架构',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body className={inter.className}>
        <div className="min-h-screen bg-background flex flex-col">
          {/* 统一企业级导航栏 */}
          <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
            <div className="container flex h-14 items-center gap-4">
              <div className="font-bold text-xl ml-4 mr-6">OSI Tutor 源问</div>
              <nav className="flex items-center gap-6 text-sm font-medium">
                <a className="transition-colors hover:text-foreground/80 text-foreground" href="/">核心课程</a>
                <a className="transition-colors hover:text-foreground/80 text-foreground/60" href="#labs">实验环境</a>
                <a className="transition-colors hover:text-foreground/80 text-foreground/60" href="#community">学习社区</a>
              </nav>
            </div>
          </header>
          {/* 主体内容区 */}
          <main className="flex-1">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
