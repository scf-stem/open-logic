import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

class DevelopmentConfig(Config):
    DEBUG = True
    # Default to local sqlite for dev
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///ositutor.db'

class ProductionConfig(Config):
    DEBUG = False
    # Fallback to local sqlite if DATABASE_URL is not set (prevents crash on Zeabur)
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///ositutor.db'
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'prod-secret-key-fallback'
